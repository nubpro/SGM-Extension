# SGM-Chrome-Extension

Additional features made available for SeriousGMOD Forum (http://seriousgmod.com).

###### The extension is available at Chrome web store:
https://chrome.google.com/webstore/detail/seriousgmod-shoutbox-exte/dmbpihmdkiieiknjnlgebnacmleljcao

###### For more information:
http://www.seriousgmod.com/threads/extension-shoutbox-now-supports-firefox.24821/
